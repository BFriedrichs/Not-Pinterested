# Not Pinterested

Instead of the website redirects you directly to the image from google search